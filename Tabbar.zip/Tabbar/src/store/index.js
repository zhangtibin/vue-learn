/*
 * @Author: ZachRobin zhangtibin_ios@163.com
 * @Date: 2022-12-12 17:38:25
 * @LastEditors: tibin.zhang tibin.zhang@huifu.com
 * @LastEditTime: 2022-12-14 13:41:00
 * @FilePath: /nzh-mini-program/src/store/index.js
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import Vue from 'vue'
import Vuex from 'vuex'
Vue.use(Vuex)
import tabBar from '@/utils/tabbar.js'
const store = new Vuex.Store({
	state: {
		tabBarList: [],
		roleId: 0, //0 用户，1 物业
	},
	mutations: {
		// 设置角色ID
		setRoleId(state, data) {
			state.roleId = data;
			uni.setStorageSync('roleId',data)
			state.tabBarList = tabBar[data];
			uni.setStorageSync('tabBarList',tabBar[data])
		},
	},
})
export default store