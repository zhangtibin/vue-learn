<!--
 * @Author: tibin.zhang tibin.zhang@huifu.com
 * @Date: 2022-11-30 10:03:32
 * @LastEditors: tibin.zhang tibin.zhang@huifu.com
 * @LastEditTime: 2022-12-14 14:28:28
 * @FilePath: /nzh-mini-program/src/pages/index/index.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
<view class="content">
    <image class="logo" src="/static/logo.png"></image>
    <view>
        <text class="title">{{title}}</text>
    </view>
    <button class="button" @click="enterApplication">进入主页面</button>
    <button class="button" @click="technicianEnterApplication">实验员登录</button>
    <button class="button" @click="customerEnterApplication">用户登录</button>
</view>
</template>

<script>
import { mapMutations } from "vuex";

export default {
    data() {
        return {            
            roleId: 1,
        }
    },
    onLoad() {

    },
    methods: {
        ...mapMutations(["setRoleId"]),
        enterApplication() {       
            this.setRoleId(this.roleId); // 0或者1
            uni.switchTab({
                url: "../detection/index", // 跳转到首页
            });
        },
        // 实验员登录
        technicianEnterApplication() {
            this.setRoleId(1); // 0或者1  
            uni.switchTab({
                url: "../detection/index", // 跳转到首页
            });           
        },
        // 用户登录
        customerEnterApplication() {
            this.setRoleId(0); // 0或者1   
            uni.switchTab({
                url: '/pages/task/index'
            });
        },
    }
}
</script>

<style>
.content {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
}

.logo {
    height: 200rpx;
    width: 200rpx;
    margin: 200rpx auto 50rpx auto;
}

.text-area {
    display: flex;
    justify-content: center;
}

.title {
    font-size: 36rpx;
    color: #8f8f94;
}

.button {
    margin-top: 30rpx;
    margin-left: 0;
    margin-right: 0;
}
</style>
