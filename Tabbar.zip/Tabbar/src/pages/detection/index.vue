<!--
 * @Author: tibin.zhang tibin.zhang@huifu.com
 * @Date: 2022-11-30 11:19:30
 * @LastEditors: tibin.zhang tibin.zhang@huifu.com
 * @LastEditTime: 2022-12-14 13:45:10
 * @FilePath: /nzh-mini-program/src/pages/index/detection/index.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
	<!-- <detectWave class="detect-wave-container">
    
	</detectWave> -->
	
    <view>       
       <button>
        页面一
       </button> 
       <tabBar />
    </view>
</template>

<script>
import tabBar from '../../components/tabBar.vue';
export default {
    components: {
        tabBar
    },
    data() {
        return {
            title: 'Hello',
        }
    },
    onLoad() {        
    },
    methods: {    
            
    }

}
</script>

<style>
body {
    background-color: #fff;
}

.detect-wave-container {
    background-color: aquamarine;
    width: 100%;
    height: 10rem;
}
</style>
