<!--
 * @Author: tibin.zhang tibin.zhang@huifu.com
 * @Date: 2022-11-30 13:53:39
 * @LastEditors: tibin.zhang tibin.zhang@huifu.com
 * @LastEditTime: 2022-12-14 13:47:14
 * @FilePath: /nzh-mini-program/src/pages/mine/index.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
    <view class="content">
        <image class="logo" src="/static/logo.png"></image>
        <view>
            <text class="title">{{title}}</text>
        </view>
        <button>
            页面四
        </button> 
        <tabBar />
    </view>
    </template>
    
    <script>
import tabBar from '../../components/tabBar.vue';
 
    export default {
        components: {
            tabBar
        }, 
        data() {
            return {
                title: 'Hello',
            }
        },
        onLoad() {
           
        },
        methods: {
            scanCode() {
                // 允许从相机和相册扫码
                uni.scanCode({
                    success: function (res) {
                        console.log('条码类型：' + res.scanType);
                        console.log('条码内容：' + res.result);
                    },
                    fail: function (res) {
                        console.log('扫码失败：' + res);
                    }
                });
            },
        }
    }
    </script>
    
    <style>
    .content {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
    }
    
    .logo {
        height: 200rpx;
        width: 200rpx;
        margin: 200rpx auto 50rpx auto;
    }
    
    .text-area {
        display: flex;
        justify-content: center;
    }
    
    .title {
        font-size: 36rpx;
        color: #8f8f94;
    }
    </style>
    