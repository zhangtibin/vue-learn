<!--
 * @Author: ZachRobin zhangtibin_ios@163.com
 * @Date: 2022-12-11 12:39:45
 * @LastEditors: tibin.zhang tibin.zhang@huifu.com
 * @LastEditTime: 2022-12-14 14:34:08
 * @FilePath: /nzh-mini-program/src/pages/task/index.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
<view class="content">
    <view>
        页面三
    </view>   
    <tabBar /> 
</view>
</template>

    
    
<script>
import tabBar from '../../components/tabBar.vue';

export default {
    components: {
        tabBar
    },
    data() {
        return {
            title: 'Hello',
            active: 0,
        }
    },
    mounted() {
        
    },
    onLoad() {

    },
    methods: {
        scanCode() {
            // 允许从相机和相册扫码
            uni.scanCode({
                success: function (res) {
                    console.log('条码类型：' + res.scanType);
                    console.log('条码内容：' + res.result);
                },
                fail: function (res) {
                    console.log('扫码失败：' + res);
                }
            });
        },
        detect() {

        }
    }
}
</script>
    
    
<style>
.content {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
}

.text-area {
    display: flex;
    justify-content: center;
}

.title {
    font-size: 36rpx;
    color: #8f8f94;
}
</style>
