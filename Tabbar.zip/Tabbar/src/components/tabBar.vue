<!--
 * @Author: ZachRobin zhangtibin_ios@163.com
 * @Date: 2022-12-12 17:42:29
 * @LastEditors: tibin.zhang tibin.zhang@huifu.com
 * @LastEditTime: 2022-12-14 13:42:44
 * @FilePath: /nzh-mini-program/src/components/tabbar.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
  <view>
    <u-tabbar
      :list="tabBarList"
      @change="change"
      v-model="current"
      :active-color="activeColor"
      :inactive-color="inactiveColor"
      :height="110"
      :border-top="borderTop"
    >
    </u-tabbar>
  </view>
</template>
<script>
export default {
  props: {
    tabBarList: {
      type: Array,
      default: () => uni.getStorageSync("tabBarList"),
    },
  },
  data() {
    return {
      borderTop: true,
      inactiveColor: "#000",
      activeColor: "#987435",
      current: 0,
    };
  },
  methods: {
    change(e) {
      const tabbar = uni.getStorageSync("tabBarList");
      console.log(tabbar);

      switch (e) {
        case 0:
          uni.switchTab({
            url: tabbar[0].pagePath,
          });
          break;
        case 1:
          uni.switchTab({
            url: tabbar[1].pagePath,
          });
          break;
        case 2:
          uni.switchTab({
            url: tabbar[2].pagePath,
          });
          break;
        case 3:
          uni.switchTab({
            url: tabbar[3].pagePath,
          });
          break;
        default:
          uni.switchTab({
            url: tabbar[0].pagePath,
          });
          break;
      }
    },
  },
};
</script>