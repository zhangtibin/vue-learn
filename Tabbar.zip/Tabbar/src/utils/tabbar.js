/*
 * @Author: ZachRobin zhangtibin_ios@163.com
 * @Date: 2022-12-12 17:33:34
 * @LastEditors: tibin.zhang tibin.zhang@huifu.com
 * @LastEditTime: 2022-12-14 13:38:39
 * @FilePath: /nzh-mini-program/src/router/modules/tabbar.js
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
// 用户tabbar
let tabUser = [
	{
        "pagePath": "/pages/task/index",
        "iconPath": "/static/tab/tab_task_nor.png",
        "selectedIconPath": "/static/tab/tab_task_sel.png",
        "text": "任务"
    }, {
        "pagePath": "/pages/device/index",
        "iconPath": "/static/tab/tab_device_nor.png",
        "selectedIconPath": "/static/tab/tab_device_sel.png",
        "text": "设备"
    }, {
        "pagePath": "/pages/mine/index",
        "iconPath": "/static/tab/tab_mine_nor.png",
        "selectedIconPath": "/static/tab/tab_mine_sel.png",
        "text": "我的"
    }
]
// 物业tabbar
let tabPro = [
	{
        "pagePath": "/pages/detection/index",
        "iconPath": "/static/tab/tab_detection_nor.png",
        "selectedIconPath": "/static/tab/tab_detection_sel.png",
        "text": "检测"
    }, {
        "pagePath": "/pages/device/index",
        "iconPath": "/static/tab/tab_device_nor.png",
        "selectedIconPath": "/static/tab/tab_device_sel.png",
        "text": "设备"
    }, {
        "pagePath": "/pages/mine/index",
        "iconPath": "/static/tab/tab_mine_nor.png",
        "selectedIconPath": "/static/tab/tab_mine_sel.png",
        "text": "我的"
    }
]
export default [
	tabUser,
    tabPro
]